# Low-Light Image Enhancement System

## Advanced Image Processing Tiny Project

A Python desktop application that improves low-light images using classical image-processing techniques.

## Features

- Open JPG, JPEG, PNG, BMP and WEBP images
- Properly displays original image
- Enhances the image using OpenCV
- Properly displays enhanced image
- Save enhanced image
- Before/after comparison
- Simple Tkinter GUI

## Image Processing Pipeline

Input Image
↓
BGR to LAB Color Space
↓
Extract L (Lightness) Channel
↓
CLAHE Contrast Enhancement
↓
Merge LAB Channels
↓
LAB to BGR
↓
Non-Local Means Denoising
↓
Gamma Correction
↓
Enhanced Output Image

## Technologies

- Python
- OpenCV
- NumPy
- Pillow
- Tkinter

## Installation

Open terminal in this project folder:

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

## How to Use

1. Click **Open Image**.
2. Select a dark/low-light photograph.
3. The original image will appear on the left.
4. Click **Enhance Image**.
5. The processed image will appear on the right.
6. Click **Save Enhanced** to save the output.

## Algorithms

### 1. LAB Color Space
LAB separates lightness from color components. This allows contrast enhancement to focus mainly on brightness.

### 2. CLAHE
Contrast Limited Adaptive Histogram Equalization improves local contrast while limiting excessive noise amplification.

### 3. Non-Local Means Denoising
This reduces noise while preserving important image details.

### 4. Gamma Correction
Gamma correction adjusts the brightness of the final image.

## Academic Project

Subject: Advanced Image Processing

Project Type: Tiny Project

## Future Scope

- Real-time webcam enhancement
- Video enhancement
- Automatic gamma selection
- Retinex-based enhancement
- Deep-learning based low-light enhancement
- Mobile application
