# ADVANCED IMAGE PROCESSING
# TINY PROJECT REPORT

## Project Title
Low-Light Image Enhancement System

## 1. Introduction

Images captured in insufficient lighting often contain low brightness, poor contrast and visible noise. Such images can be difficult to understand and process.

This project develops a Python-based image enhancement system that improves low-light photographs using classical digital image-processing techniques.

## 2. Problem Statement

Low-light images generally suffer from poor visibility and low contrast. The objective is to improve the visual quality of these images while preserving useful details.

## 3. Objectives

- Read a user-selected image.
- Display the original image.
- Convert the image to LAB color space.
- Improve local contrast using CLAHE.
- Reduce noise.
- Apply gamma correction.
- Display the enhanced image.
- Save the enhanced result.

## 4. Software Requirements

- Python 3.9 or later
- OpenCV
- NumPy
- Pillow
- Tkinter

## 5. Hardware Requirements

- Laptop or desktop computer
- Minimum 4 GB RAM recommended
- Standard display

## 6. Methodology

### Step 1: Input Image
The user selects a low-light image from the computer.

### Step 2: LAB Conversion
The image is converted from BGR to LAB color space.

### Step 3: CLAHE
The L channel is processed using Contrast Limited Adaptive Histogram Equalization.

### Step 4: Image Reconstruction
The enhanced L channel is combined with the original A and B channels.

### Step 5: Denoising
Non-local Means Denoising is applied to reduce unwanted noise.

### Step 6: Gamma Correction
Gamma correction is applied to adjust the brightness.

### Step 7: Output
The enhanced image is displayed beside the original image and can be saved.

## 7. Advantages

- Simple to use
- Does not require a trained ML model
- Fast processing
- Works with common image formats
- Demonstrates multiple image-processing techniques

## 8. Applications

- Night photography
- CCTV preprocessing
- Image restoration
- Mobile photography
- Document enhancement
- Preprocessing for computer vision systems

## 9. Limitations

The system cannot recover image information that was never captured by the camera. Extremely dark images may still contain insufficient detail.

## 10. Future Scope

The project can be extended with:
- Real-time camera processing
- Video enhancement
- Automatic parameter optimization
- Retinex algorithms
- CNN-based enhancement
- Zero-DCE or other deep-learning approaches

## 11. Conclusion

The Low-Light Image Enhancement System demonstrates how multiple advanced image-processing operations can be combined into a practical application. LAB color processing, CLAHE, denoising and gamma correction improve the brightness and visibility of low-light images.
