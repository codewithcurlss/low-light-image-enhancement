import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import cv2
import numpy as np
import os

class LowLightEnhancer:
    def __init__(self, root):
        self.root = root
        self.root.title("Low-Light Image Enhancement | Advanced Image Processing")
        self.root.geometry("1250x780")
        self.root.minsize(1000, 650)

        self.original_image = None
        self.enhanced_image = None
        self.original_path = None

        title = tk.Label(
            root,
            text="LOW-LIGHT IMAGE ENHANCEMENT SYSTEM",
            font=("Arial", 22, "bold")
        )
        title.pack(pady=(15, 5))

        subtitle = tk.Label(
            root,
            text="Advanced Image Processing using LAB + CLAHE + Denoising + Gamma Correction",
            font=("Arial", 11)
        )
        subtitle.pack(pady=(0, 15))

        toolbar = tk.Frame(root)
        toolbar.pack(pady=5)

        tk.Button(
            toolbar, text="📂 Open Image",
            command=self.open_image,
            font=("Arial", 11, "bold"),
            padx=18, pady=8
        ).pack(side=tk.LEFT, padx=6)

        tk.Button(
            toolbar, text="✨ Enhance Image",
            command=self.enhance,
            font=("Arial", 11, "bold"),
            padx=18, pady=8
        ).pack(side=tk.LEFT, padx=6)

        tk.Button(
            toolbar, text="💾 Save Enhanced",
            command=self.save_image,
            font=("Arial", 11, "bold"),
            padx=18, pady=8
        ).pack(side=tk.LEFT, padx=6)

        tk.Button(
            toolbar, text="🔄 Clear",
            command=self.clear,
            font=("Arial", 11, "bold"),
            padx=18, pady=8
        ).pack(side=tk.LEFT, padx=6)

        image_frame = tk.Frame(root)
        image_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        left = tk.LabelFrame(
            image_frame,
            text="Original Image",
            font=("Arial", 13, "bold")
        )
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=8)

        right = tk.LabelFrame(
            image_frame,
            text="Enhanced Image",
            font=("Arial", 13, "bold")
        )
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=8)

        self.original_label = tk.Label(
            left,
            text="No image selected",
            font=("Arial", 13)
        )
        self.original_label.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.enhanced_label = tk.Label(
            right,
            text="Enhanced image will appear here",
            font=("Arial", 13)
        )
        self.enhanced_label.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.status = tk.Label(
            root,
            text="Ready — Open a low-light image to begin.",
            anchor="w",
            font=("Arial", 10)
        )
        self.status.pack(fill=tk.X, padx=25, pady=(0, 12))

    def open_image(self):
        path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[
                ("Image Files", "*.jpg *.jpeg *.png *.bmp *.webp"),
                ("All Files", "*.*")
            ]
        )

        if not path:
            return

        image = cv2.imread(path)

        if image is None:
            messagebox.showerror("Error", "Could not read this image.")
            return

        self.original_path = path
        self.original_image = image
        self.enhanced_image = None

        self.display_image(image, self.original_label)
        self.enhanced_label.config(image="", text="Click 'Enhance Image'")
        self.enhanced_label.image = None

        self.status.config(
            text=f"Loaded: {os.path.basename(path)}"
        )

    def enhance(self):
        if self.original_image is None:
            messagebox.showwarning(
                "No Image",
                "Please open an image first."
            )
            return

        image = self.original_image.copy()

        # Step 1: BGR -> LAB
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

        # Step 2: Separate lightness channel
        l_channel, a_channel, b_channel = cv2.split(lab)

        # Step 3: CLAHE for local contrast enhancement
        clahe = cv2.createCLAHE(
            clipLimit=2.5,
            tileGridSize=(8, 8)
        )
        enhanced_l = clahe.apply(l_channel)

        # Step 4: Merge LAB channels
        enhanced_lab = cv2.merge(
            (enhanced_l, a_channel, b_channel)
        )

        # Step 5: LAB -> BGR
        enhanced = cv2.cvtColor(
            enhanced_lab,
            cv2.COLOR_LAB2BGR
        )

        # Step 6: Noise reduction
        enhanced = cv2.fastNlMeansDenoisingColored(
            enhanced,
            None,
            3,
            3,
            7,
            21
        )

        # Step 7: Gamma correction
        gamma = 0.85
        lookup_table = np.array([
            ((i / 255.0) ** gamma) * 255
            for i in np.arange(256)
        ]).astype("uint8")

        enhanced = cv2.LUT(enhanced, lookup_table)

        self.enhanced_image = enhanced

        self.display_image(enhanced, self.enhanced_label)

        self.status.config(
            text="Enhancement completed: LAB → CLAHE → Denoising → Gamma Correction"
        )

    def display_image(self, cv_image, label):
        # OpenCV BGR -> RGB
        rgb = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)

        pil_image = Image.fromarray(rgb)

        # Get available display area
        max_width = 520
        max_height = 510

        width, height = pil_image.size
        scale = min(
            max_width / width,
            max_height / height,
            1
        )

        new_size = (
            max(1, int(width * scale)),
            max(1, int(height * scale))
        )

        pil_image = pil_image.resize(
            new_size,
            Image.Resampling.LANCZOS
        )

        photo = ImageTk.PhotoImage(pil_image)

        label.config(image=photo, text="")
        label.image = photo

    def save_image(self):
        if self.enhanced_image is None:
            messagebox.showwarning(
                "No Enhanced Image",
                "Please enhance an image first."
            )
            return

        path = filedialog.asksaveasfilename(
            title="Save Enhanced Image",
            defaultextension=".png",
            filetypes=[
                ("PNG Image", "*.png"),
                ("JPEG Image", "*.jpg")
            ]
        )

        if not path:
            return

        cv2.imwrite(path, self.enhanced_image)

        self.status.config(
            text=f"Saved enhanced image: {os.path.basename(path)}"
        )

        messagebox.showinfo(
            "Saved",
            "Enhanced image saved successfully!"
        )

    def clear(self):
        self.original_image = None
        self.enhanced_image = None
        self.original_path = None

        self.original_label.config(
            image="",
            text="No image selected"
        )
        self.original_label.image = None

        self.enhanced_label.config(
            image="",
            text="Enhanced image will appear here"
        )
        self.enhanced_label.image = None

        self.status.config(
            text="Ready — Open a low-light image to begin."
        )


if __name__ == "__main__":
    root = tk.Tk()
    app = LowLightEnhancer(root)
    root.mainloop()
