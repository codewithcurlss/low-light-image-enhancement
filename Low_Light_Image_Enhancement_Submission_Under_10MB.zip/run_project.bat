@echo off
echo ================================================
echo Low-Light Image Enhancement System
echo ================================================
echo.
echo Installing required packages...
pip install -r requirements.txt
echo.
echo Starting application...
python main.py
pause
